#!/bin/bash
git clone https://github.com/gkaramanolakis/SpanBERT
cd SpanBERT
pip3 install -r requirements.txt
bash download_finetuned.sh
cp -R * ../
cd ..
